oranges=50
bananas=40

total= oranges + bananas
print(total)
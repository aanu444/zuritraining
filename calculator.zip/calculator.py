inputField=input("Enter a number = ")
print (int(inputField) + 3) #addition
print (int(inputField) - 6) #subtraction
print (int(inputField) / 5) #division
print (int(inputField) * 4) #multiplication
print (int(inputField) % 2) #modulus